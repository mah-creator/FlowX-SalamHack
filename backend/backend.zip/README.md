# Salamhack Backend

This Laravel application is the Phase 2 backend foundation for the Salamhack prototype.

Primary references:

- Setup and validation: `../specs/003-backend-foundation/quickstart.md`
- Route contract: `../specs/003-backend-foundation/contracts/route-registry.md`
- Implementation plan: `../specs/003-backend-foundation/plan.md`

Phase 2 scope:

- Register all 18 Phase 1 API paths exactly as documented, with no `/api` prefix.
- Return a canonical `501 not_implemented` error envelope from product endpoint stubs.
- Expose public `GET /healthz`.
- Enforce Bearer-token presence only on authenticated routes.
- Render all non-2xx responses through the canonical error envelope.
- Avoid business logic, persistence, migrations, Eloquent models, and frontend changes.

Phase 4 validation and response shaping:

- Endpoint validation should use Laravel FormRequest classes.
- Validation failures must be rendered centrally as `error.code=validation_failed`.
- Successful business responses should use Laravel API Resources or ResourceCollections.
- Controllers should stay thin and delegate domain behavior to services introduced in later phases.
