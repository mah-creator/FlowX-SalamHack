<?php

use App\Http\Controllers\AdminTransactionController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HealthController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Route;

Route::get('/healthz', [HealthController::class, 'show'])->name('healthz.show');

Route::middleware('auth.bearer.presence')->group(function (): void {
    Route::get('/transactions', [TransactionController::class, 'index'])->name('transactions.index');
    Route::get('/transactions/{id}', [TransactionController::class, 'show'])->name('transactions.show');
    Route::post('/transactions', [TransactionController::class, 'store'])->name('transactions.store');
    Route::post('/transactions/{id}/cancel', [TransactionController::class, 'cancel'])->name('transactions.cancel');
    Route::post('/transactions/{id}/confirm-match', [TransactionController::class, 'confirmMatch'])->name('transactions.confirm-match');
    Route::post('/transactions/{id}/deposits', [TransactionController::class, 'confirmDeposit'])->name('transactions.deposits');
    Route::post('/transactions/{id}/process-payouts', [TransactionController::class, 'processPayouts'])->name('transactions.process-payouts');
    Route::post('/transactions/{id}/disputes', [TransactionController::class, 'openDispute'])->name('transactions.disputes');
    Route::post('/transactions/{id}/auto-match', [TransactionController::class, 'autoMatch'])->name('transactions.auto-match');

    Route::get('/admin/transactions', [AdminTransactionController::class, 'index'])->name('admin.transactions.index');
    Route::post('/admin/transactions/{id}/flag-risk', [AdminTransactionController::class, 'flagRisk'])->name('admin.transactions.flag-risk');
    Route::post('/admin/transactions/{id}/approve', [AdminTransactionController::class, 'approve'])->name('admin.transactions.approve');
    Route::post('/admin/transactions/{id}/refund', [AdminTransactionController::class, 'refund'])->name('admin.transactions.refund');
    Route::post('/admin/transactions/{id}/resolve-dispute', [AdminTransactionController::class, 'resolveDispute'])->name('admin.transactions.resolve-dispute');

    Route::post('/auth/verify', [AuthController::class, 'verify'])->name('auth.verify');
    Route::post('/auth/logout', [AuthController::class, 'logout'])->name('auth.logout');
});

Route::post('/auth/signup', [AuthController::class, 'signup'])->name('auth.signup');
Route::post('/auth/login', [AuthController::class, 'login'])->name('auth.login');
