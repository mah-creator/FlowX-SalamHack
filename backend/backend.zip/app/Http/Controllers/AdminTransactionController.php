<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ReturnsNotImplemented;
use Illuminate\Http\JsonResponse;

class AdminTransactionController extends Controller
{
    use ReturnsNotImplemented;

    public function index(): JsonResponse
    {
        return $this->notImplemented('EP-009');
    }

    public function flagRisk(string $id): JsonResponse
    {
        return $this->notImplemented('EP-011');
    }

    public function approve(string $id): JsonResponse
    {
        return $this->notImplemented('EP-012');
    }

    public function refund(string $id): JsonResponse
    {
        return $this->notImplemented('EP-013');
    }

    public function resolveDispute(string $id): JsonResponse
    {
        return $this->notImplemented('EP-014');
    }
}
