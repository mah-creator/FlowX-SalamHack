<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ReturnsNotImplemented;
use Illuminate\Http\JsonResponse;

class TransactionController extends Controller
{
    use ReturnsNotImplemented;

    public function index(): JsonResponse
    {
        return $this->notImplemented('EP-001');
    }

    public function show(string $id): JsonResponse
    {
        return $this->notImplemented('EP-002');
    }

    public function store(): JsonResponse
    {
        return $this->notImplemented('EP-003');
    }

    public function cancel(string $id): JsonResponse
    {
        return $this->notImplemented('EP-004');
    }

    public function confirmMatch(string $id): JsonResponse
    {
        return $this->notImplemented('EP-005');
    }

    public function confirmDeposit(string $id): JsonResponse
    {
        return $this->notImplemented('EP-006');
    }

    public function processPayouts(string $id): JsonResponse
    {
        return $this->notImplemented('EP-007');
    }

    public function openDispute(string $id): JsonResponse
    {
        return $this->notImplemented('EP-008');
    }

    public function autoMatch(string $id): JsonResponse
    {
        return $this->notImplemented('EP-010');
    }
}
