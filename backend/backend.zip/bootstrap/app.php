<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        apiPrefix: '',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->prepend(\App\Http\Middleware\StrictCorsOrigin::class);
        $middleware->append(\Illuminate\Http\Middleware\HandleCors::class);
        $middleware->append(\App\Http\Middleware\StructuredRequestLog::class);

        $middleware->alias([
            'auth.bearer.presence' => \App\Http\Middleware\BearerPresenceAuth::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn (Request $request, Throwable $e): bool => true);

        $exceptions->render(function (ValidationException $e, Request $request) {
            return \App\Support\ErrorEnvelope::attachRequestId(
                \App\Support\ErrorEnvelope::validationFailed($e->errors()),
                $request,
            );
        });

        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            return \App\Support\ErrorEnvelope::attachRequestId(
                \App\Support\ErrorEnvelope::notFound(),
                $request,
            );
        });

        $exceptions->render(function (MethodNotAllowedHttpException $e, Request $request) {
            $allow = $e->getHeaders()['Allow'] ?? '';

            return \App\Support\ErrorEnvelope::attachRequestId(
                \App\Support\ErrorEnvelope::methodNotAllowed($allow === '' ? [] : explode(', ', $allow)),
                $request,
            );
        });

        $exceptions->render(function (Throwable $e, Request $request) {
            return \App\Support\ErrorEnvelope::attachRequestId(
                \App\Support\ErrorEnvelope::internalError(),
                $request,
            );
        });
    })->create();
